test_that("the permutation statistic matches Box.test before calibration", {
  set.seed(87)
  x <- expm1(matrix(rnorm(7 * 30, 3, .15), 7))
  result <- winn:::.compute_permutation_ljung_box(x, 6L, 19L)
  reference <- apply(x, 1, function(y) unname(Box.test(log1p(y), lag = 6L, type = "Ljung-Box")$statistic))
  expect_equal(result$statistic, reference, tolerance = 1e-12)
  expect_true(all(result$raw_p_value >= 1 / 20))
  expect_true(all(result$adjusted_p_value >= result$raw_p_value))
})

test_that("maxT and raw p-values agree with exhaustive small-sample permutations", {
  permutations_of <- function(x) {
    if (length(x) == 1L) return(matrix(x, 1L))
    do.call(cbind, lapply(seq_along(x), function(i) {
      rbind(x[i], permutations_of(x[-i]))
    }))
  }
  permutations <- permutations_of(1:4)
  x <- expm1(rbind(c(2, 2.3, 3, 3.8), c(2.8, 2.1, 3.5, 2.4)))
  reference <- apply(permutations, 2L, function(index) {
    apply(x[, index], 1L, function(y) unname(Box.test(log1p(y), lag = 3L, type = "Ljung-Box")$statistic))
  })
  observed <- reference[, 1L]
  tolerance <- 1e-12 * pmax(1, abs(observed))
  expected_raw <- rowMeans(reference >= observed - tolerance)
  expected_adjusted <- vapply(seq_along(observed), function(i) {
    mean(apply(reference, 2L, max) >= observed[i] - tolerance[i])
  }, numeric(1))
  # The helper adds the identity via +1, so provide all other permutations.
  result <- winn:::.compute_permutation_ljung_box(x, 3L,
    permutations = permutations[, -1L, drop = FALSE])
  expect_equal(result$raw_p_value, expected_raw, tolerance = 1e-14)
  expect_equal(result$adjusted_p_value, expected_adjusted, tolerance = 1e-14)
})

test_that("local permutation randomness is reproducible and restores caller RNG", {
  set.seed(134)
  x <- expm1(matrix(rnorm(100, 3, .15), 5))
  saved_seed <- .Random.seed
  saved_kind <- RNGkind()
  first <- winn:::.compute_permutation_ljung_box(x, 4L, 39L, 83L)
  expect_identical(.Random.seed, saved_seed)
  expect_identical(RNGkind(), saved_kind)
  runif(7)
  second <- winn:::.compute_permutation_ljung_box(x, 4L, 39L, 83L)
  expect_identical(first, second)
  third <- winn:::.compute_permutation_ljung_box(x, 4L, 39L, 84L)
  expect_false(identical(first$permutation_maxima, third$permutation_maxima))
  old_seed <- .Random.seed
  on.exit(assign(".Random.seed", old_seed, envir = .GlobalEnv), add = TRUE)
  rm(".Random.seed", envir = .GlobalEnv)
  invisible(winn:::.compute_permutation_ljung_box(x, 4L, 19L))
  expect_false(exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE))
})

test_that("untestable profiles are excluded without corrupting permutation maxima", {
  x <- rbind(seq(5, 30), rep(5, 26), c(NA, rep(6, 25)))
  result <- winn:::.compute_permutation_ljung_box(x, 5L, 19L)
  expect_true(is.finite(result$raw_p_value[1]))
  expect_true(all(is.na(result$raw_p_value[2:3])))
  expect_true(all(is.finite(result$permutation_maxima)))
  short <- winn:::.compute_permutation_ljung_box(x[, 1:3], NA_integer_, 19L)
  expect_true(all(is.na(short$adjusted_p_value)))
  constant <- winn:::.compute_permutation_ljung_box(matrix(5, 2, 20), 4L, 19L)
  expect_length(constant$permutation_maxima, 0)
  expect_true(all(is.na(constant$adjusted_p_value)))
})

test_that("cached and direct paths share the same calibrated gate and correction", {
  set.seed(89)
  z <- matrix(rnorm(12 * 40, 3, .08), 12)
  z[1:4, ] <- sweep(z[1:4, ], 2, rep(seq(-.7, .7, length.out = 20), 2), "+")
  x <- expm1(z)
  batch <- rep(1:2, each = 20)
  for (calibration in c("permutation", "asymptotic")) {
    direct <- autocorrelation_correct(x, batch = batch, return_diagnostics = TRUE,
      drift_calibration = calibration, n_permutations = 99L)
    cached <- winn:::.prepare_autocorrelation_correction(
      x, seq_len(40), batch, NULL, "Ljung-Box", 0L, "mean", "conservative", .05,
      drift_calibration = calibration, n_permutations = 99L)
    materialized <- winn:::.materialize_autocorrelation_correction(cached, .05)
    expect_equal(materialized, direct$data, tolerance = 1e-10)
    expect_equal(unlist(lapply(cached$batches, `[[`, "adjusted_p")),
      direct$diagnostics$adjusted_p_value, tolerance = 1e-14)
    candidates <- winn:::.materialize_autocorrelation_candidates(cached, c(.01, .05))
    expect_true(length(candidates) >= 1L)
  }
})

test_that("asymptotic opt-in reproduces Box.test and BH while new options validate", {
  set.seed(90)
  x <- expm1(matrix(rnorm(200, 3, .2), 10))
  expected <- apply(x, 1, function(y) Box.test(log1p(y), lag = 4, fitdf = 1, type = "Ljung-Box")$p.value)
  actual <- autocorrelation_correct(x, batch = rep(1, 20),
    drift_calibration = "asymptotic", ljung_box_fitdf = 1L,
    return_diagnostics = TRUE)$diagnostics
  expect_equal(actual$raw_p_value, expected, tolerance = 1e-12)
  expect_equal(actual$adjusted_p_value, p.adjust(expected, "BH"), tolerance = 1e-12)
  expect_true(all(actual$multiplicity_adjustment == "BH"))
  expect_true(all(actual$n_permutations == 0L))
  expect_error(autocorrelation_correct(x, batch = rep(1, 20), ljung_box_fitdf = 1),
    "must be 0")
  expect_error(autocorrelation_correct(x, batch = rep(1, 20), n_permutations = 0),
    "n_permutations")
  expect_error(autocorrelation_correct(x, batch = rep(1, 20), permutation_seed = NA_real_),
    "permutation_seed")
  expect_error(autocorrelation_correct(x, batch = rep(1, 20), drift_calibration = "bad"),
    "arg")
})
